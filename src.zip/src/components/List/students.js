const students = [
    {
        name:'Juan Luna',
        isMember:false
    },
    {
        name:'Lucas Vazquez',
        isMember:true
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'German Pino',
        isMember:false
    },
    {
        name:'Luciano Gonzalez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'Rocio Dorado',
        isMember:true
    },
    
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'German Pino',
        isMember:false
    },
    {
        name:'Luciano Gonzalez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'Mateo Gonzalez',
        isMember:true
    },
    
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'German Pino',
        isMember:false
    },
    {
        name:'Luciano Gonzalez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'German Pino',
        isMember:false
    },
    {
        name:'Luciano Gonzalez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'Juan Gomez',
        isMember:false
    },
    {
        name:'German Pino',
        isMember:false
    },
    {
        name:'Luciano Gonzalez',
        isMember:false
    }
]
export default students;